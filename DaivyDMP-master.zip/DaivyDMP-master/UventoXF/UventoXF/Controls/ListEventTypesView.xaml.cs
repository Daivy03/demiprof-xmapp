﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UventoXF.Controls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ListEventTypesView : ContentView
    {
        public ListEventTypesView()
        {
            InitializeComponent();
        }
    }
}