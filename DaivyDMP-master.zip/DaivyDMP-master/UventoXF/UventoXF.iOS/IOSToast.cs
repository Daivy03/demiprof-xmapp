﻿using Foundation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UIKit;
using UventoXF.Interfaces;

namespace UventoXF.iOS
{
    public class IOSToast : IToast
    {
        public void Show(string message)
        {
            // TODO: non implementare nulla :)
        }
    }
}