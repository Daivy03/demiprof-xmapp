﻿namespace UventoXF.Models
{
    public class EventItem
    {
        public string title { get; set; }
//        public string date { get; set; }
        public string classinfo { get; set; }
        public string image { get; set; }
    }
}
