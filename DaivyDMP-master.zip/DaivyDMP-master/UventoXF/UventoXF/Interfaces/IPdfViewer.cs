﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UventoXF.Interfaces
{
    public interface IPdfViewer
    {
        void ShowDocument(string filePath);
    }

}
