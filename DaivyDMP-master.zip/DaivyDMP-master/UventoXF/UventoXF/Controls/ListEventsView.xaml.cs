﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace UventoXF.Controls
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ListEventsView : ContentView
    {
        public ListEventsView()
        {
            InitializeComponent();
        }
    }
}