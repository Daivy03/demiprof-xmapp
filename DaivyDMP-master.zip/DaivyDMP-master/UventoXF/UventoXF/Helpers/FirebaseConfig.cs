﻿using System;
using System.Collections.Generic;
using System.Text;

namespace UventoXF.Helpers
{
    public static class FirebaseConfig
    {
        public static string FirebaseUrl = "https://demiprof-b12be-default-rtdb.europe-west1.firebasedatabase.app/";
    }
}