﻿namespace UventoXF.Interfaces
{
    public interface IStatusbarColor
    {
        void ChangeStatusbarColor();
    }
}
